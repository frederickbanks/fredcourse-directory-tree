# The DeeCee Directoree Tree

Oh noes! The NSA has gone too far in trying to reduce the whole nation to a
bunch of data points. Now the entire DMV (DC/Maryland/Virginia) area is a
directory tree!

You need to figure out how to navigate this place. Write out the absolute and
(if applicable) relative paths you would use to go...

- From outside the DMV to Lincoln (use absolute path)
- From Lincoln to Chad
- From Chad to Arielle.
- From Arielle to Nadia
- From Nadia to Rachel
- From Rachel to Paul

---

The data has been visualized in the attached `index.html` file, viewable at
https://ga-wdi-exercises.github.io/dc_directory_tree. A matching directory tree
is contained in the `dmv` folder.

Open it and use your console to test your answers!
